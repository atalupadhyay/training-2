﻿using System;

namespace Komsky.Web.Models
{
    public class CustomerViewModel
    {
        public Int32 Id { get; set; }
        public String Name { get; set; }
    }
}