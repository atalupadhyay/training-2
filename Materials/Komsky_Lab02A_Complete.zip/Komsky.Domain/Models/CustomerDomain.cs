﻿using System;
using System.Collections;

namespace Komsky.Domain.Models
{
    public class CustomerDomain
    {
        public Int32 Id { get; set; }
        public String Name { get; set; }

    }
}
