﻿namespace Komsky.Enums
{
    public enum TicketState
    {
        Created,
        Assigned,
        InProgress,
        Solved,
        Reopened
    }
}
