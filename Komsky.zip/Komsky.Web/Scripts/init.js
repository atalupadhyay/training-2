﻿$(document).ready(function() {
    GLOBAL.Search.Init();
    GLOBAL.Modals.Init();
});