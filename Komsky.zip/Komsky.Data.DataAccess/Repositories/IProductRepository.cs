﻿using Komsky.Data.Entities;

namespace Komsky.Data.DataAccess.Repositories
{
    public interface IProductRepository : IRepository<Product> {}
}
