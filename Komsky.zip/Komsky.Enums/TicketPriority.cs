﻿namespace Komsky.Enums
{
    public enum TicketPriority
    {
        Normal,
        Highest,
        High,
        Low,
        Lowest
    }
}
