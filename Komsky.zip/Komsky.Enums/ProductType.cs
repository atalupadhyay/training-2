﻿namespace Komsky.Enums
{
    public enum ProductType
    {
        Software,
        Hardware,
        Other   
    }
}
